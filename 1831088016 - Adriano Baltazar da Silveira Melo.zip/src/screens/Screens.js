// Aluno: Adriano Baltazar da Silveira Melo - 1831088016

import App from './App'
import Login from './Login'; 
import Register from './Register';
import ToDoTasks from './ToDoTasks'; 
import DoneTasks from './DoneTasks';
import Task from './Task';

export {
    App,
    Login,
    Register,
    ToDoTasks,
    DoneTasks,
    Task
};