// Aluno: Adriano Baltazar da Silveira Melo - 1831088016

import TaskListView from './TaskListView';

export {
    TaskListView
}