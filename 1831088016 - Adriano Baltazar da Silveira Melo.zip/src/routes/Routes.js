// Aluno: Adriano Baltazar da Silveira Melo - 1831088016

import { createStackNavigator, createAppContainer, createBottomTabNavigator, createMaterialTopTabNavigator } from 'react-navigation';
import { App, Login, Register, ToDoTasks, DoneTasks, Task } from '../screens/Screens';
import { Platform } from 'react-native';

const taskListTabNavigatorIos = createBottomTabNavigator({ 
    pageToDoTasks: { screen: ToDoTasks, title: 'To Do' },
    pageDoneTasks: { screen: DoneTasks, title: 'Done' } 
});

const taskListTabNavigatorAndroid = createMaterialTopTabNavigator({ 
    pageToDoTasks: { screen: ToDoTasks, title: 'To Do' },
    pageDoneTasks: { screen: DoneTasks, title: 'Done' } 
});

export default Routes = createAppContainer(createStackNavigator(
    {
        pageApp: { screen: App },
        pageLogin: { screen: Login }, 
        pageRegister: { screen: Register },
        pageTasksList: {
            ...Platform.select({ 
                ios: {
                    screen: taskListTabNavigatorIos, 
                    navigationOptions: {
                        title: 'Task List' 
                    }
                },
                android: {
                    screen: taskListTabNavigatorAndroid, 
                    navigationOptions: {
                        header: null
                    }
                }
            }) 
        },
        pageTask: { screen: Task }
    }, 
    {
        headerMode: 'screen'
    }
));